<ul class="account-nav">
    <li><a href="<?php echo e(route('user.index')); ?>" class="menu-link menu-link_us-s">Bảng điều khiển</a></li>
    <li><a href="<?php echo e(route('user.orders')); ?>" class="menu-link menu-link_us-s">Đơn hàng</a></li>
    <li><a href="account-address.html" class="menu-link menu-link_us-s">Địa chỉ</a></li>
    <li><a href="account-details.html" class="menu-link menu-link_us-s">Chi tiết tài khoản</a></li>
    <li><a href="account-wishlist.html" class="menu-link menu-link_us-s">Danh sách yêu thích</a></li>
    <li>
        <form method="POST" action="<?php echo e(route('logout')); ?>" id="logout-form">
            <?php echo csrf_field(); ?>
            <a href="<?php echo e(route('logout')); ?>" class="menu-link menu-link_us-s" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Đăng xuất</a>
        </form>
    </li>
</ul>
<?php /**PATH D:\Project\laravel11ecommerce\resources\views/user/account-nav.blade.php ENDPATH**/ ?>