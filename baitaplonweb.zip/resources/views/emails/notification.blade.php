<!DOCTYPE html>
<html>
<head>
    <title>Cảm ơn bạn đã đánh giá sản phẩm!</title>
</head>
<body>
    <h1>Cảm ơn!</h1>
    <p>Chúng tôi cảm ơn bạn vì đã đánh giá sản phẩm.</p>
    <p>Đánh giá của bạn giúp chúng tôi cải thiện dịch vụ và mang đến trải nghiệm tốt hơn cho khách hàng.</p>
    <p>Chúc bạn một ngày tốt lành!</p>
</body>
</html>
